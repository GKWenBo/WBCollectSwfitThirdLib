# Change Log

---

## [1.1.0](https://github.com/kakaopensource/KakaJSON/releases/tag/1.1.0) (2019-08-27)
- Remove locks in ConvertibleConfig
- Simplify apis
- Support carthage
- Merged pull requests
	- [simplify optional.kj_value](https://github.com/kakaopensource/KakaJSON/pull/16)
	- [replace symbol ~= with pattern keyword](https://github.com/kakaopensource/KakaJSON/pull/17)

## [1.0.0](https://github.com/kakaopensource/KakaJSON/releases/tag/1.0.0) (2019-08-23)
- First public release