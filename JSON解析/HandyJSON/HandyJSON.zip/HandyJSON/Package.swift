import PackageDescription

let package = Package(
    name: "HandyJSON"
)

