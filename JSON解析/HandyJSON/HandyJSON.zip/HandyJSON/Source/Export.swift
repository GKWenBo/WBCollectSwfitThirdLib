//
//  Export.swift
//  HandyJSON
//
//  Created by zhouzhuo on 16/07/2017.
//  Copyright © 2017 aliyun. All rights reserved.
//

import Foundation

public protocol HandyJSONCustomTransformable: _ExtendCustomBasicType {}

public protocol HandyJSON: _ExtendCustomModelType {}

public protocol HandyJSONEnum: _RawEnumProtocol {}
