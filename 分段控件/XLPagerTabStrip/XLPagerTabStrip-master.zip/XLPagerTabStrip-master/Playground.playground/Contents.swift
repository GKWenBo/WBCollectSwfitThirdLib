//
//  Playground.playground
//  XLPagerTabStrip
//
//  Copyright © 2016 Xmartlabs SRL. All rights reserved.
//

//: Playground - noun: a place where people can play

import UIKit
import XLPagerTabStrip

var helloWorld = "Hello, playground"
