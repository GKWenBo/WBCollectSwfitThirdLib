//
//  XLPagerTabStrip.h
//  XLPagerTabStrip
//
//  Copyright © 2016 Xmartlabs SRL. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for XLPagerTabStrip.
FOUNDATION_EXPORT double XLPagerTabStripVersionNumber;

//! Project version string for XLPagerTabStrip.
FOUNDATION_EXPORT const unsigned char XLPagerTabStripVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XLPagerTabStrip/PublicHeader.h>

#import "FXPageControl.h"

