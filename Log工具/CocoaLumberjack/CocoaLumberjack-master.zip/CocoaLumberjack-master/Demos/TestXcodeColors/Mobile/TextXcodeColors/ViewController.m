//
//  ViewController.m
//  TextXcodeColors
//
//  CocoaLumberjack Demos
//

#import "ViewController.h"

@implementation ViewController

@synthesize label;

@end
