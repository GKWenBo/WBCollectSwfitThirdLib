//
//  ThirdPartyFramework.h
//  ContextFilter
//
//  CocoaLumberjack Demos
//

#import <Foundation/Foundation.h>

#define TP_LOG_CONTEXT 1044

@interface ThirdPartyFramework : NSObject

+ (void)start;

@end
