//
//  MyContextFilter.h
//  ContextFilter
//
//  CocoaLumberjack Demos
//

#import <Foundation/Foundation.h>
#import <CocoaLumberjack/CocoaLumberjack.h>

@interface MyContextFilter : NSObject <DDLogFormatter>

@end
