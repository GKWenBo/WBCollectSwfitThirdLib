//
//  TimerTwo.h
//  FineGrainedLogging
//
//  CocoaLumberjack Demos
//

#import <Cocoa/Cocoa.h>

@interface TimerTwo : NSObject
{
    NSTimer *foodTimer;
    NSTimer *sleepTimer;
}

@end
