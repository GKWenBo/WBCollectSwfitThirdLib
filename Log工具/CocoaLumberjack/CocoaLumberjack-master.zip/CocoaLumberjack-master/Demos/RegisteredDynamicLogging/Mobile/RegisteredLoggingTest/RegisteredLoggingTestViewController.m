//
//  RegisteredLoggingTestViewController.m
//  RegisteredLoggingTest
//
//  CocoaLumberjack Demos
//

#import "RegisteredLoggingTestViewController.h"

@implementation RegisteredLoggingTestViewController

@end
