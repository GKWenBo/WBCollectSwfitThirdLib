//
//  RegisteredLoggingTestViewController.h
//  RegisteredLoggingTest
//
//  CocoaLumberjack Demos
//

#import <UIKit/UIKit.h>

@interface RegisteredLoggingTestViewController : UIViewController

@end
