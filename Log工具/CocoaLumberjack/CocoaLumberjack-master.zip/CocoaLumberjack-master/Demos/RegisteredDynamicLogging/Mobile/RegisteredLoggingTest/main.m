//
//  main.m
//  RegisteredLoggingTest
//
//  CocoaLumberjack Demos
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, nil);
        return retVal;
    }
}
