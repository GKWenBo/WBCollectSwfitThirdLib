//
//  RegisteredLoggingTestAppDelegate.h
//  RegisteredLoggingTest
//
//  CocoaLumberjack Demos
//

#import <Cocoa/Cocoa.h>

@interface RegisteredLoggingTestAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *__unsafe_unretained window;
}

@property (unsafe_unretained) IBOutlet NSWindow *window;

@end
