//
//  Lions.h
//  RegisteredLoggingTest
//
//  CocoaLumberjack Demos
//

#import <Foundation/Foundation.h>

@interface Lions : NSObject

+ (void)logStuff;

@end
