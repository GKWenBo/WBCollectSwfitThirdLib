//
//  SlowLogger.h
//  OverflowTestMac
//
//  CocoaLumberjack Demos
//

#import <Foundation/Foundation.h>
#import <CocoaLumberjack/CocoaLumberjack.h>

@interface SlowLogger : DDAbstractLogger <DDLogger>

@end
