//
//  UniversalAppViewController.h
//  UniversalApp
//
//  CocoaLumberjack Demos
//

#import <UIKit/UIKit.h>

@interface UniversalAppViewController : UIViewController

@end
