//
//  UniversalAppViewController.m
//  UniversalApp
//
//  CocoaLumberjack Demos
//

#import "UniversalAppViewController.h"

@implementation UniversalAppViewController

@end
