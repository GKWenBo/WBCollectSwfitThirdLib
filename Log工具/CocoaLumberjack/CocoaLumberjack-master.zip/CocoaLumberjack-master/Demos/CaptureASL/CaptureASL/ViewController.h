//
//  ViewController.h
//  CaptureASL
//
//  CocoaLumberjack Demos
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)log:(id)sender;
- (IBAction)asl_log:(UIButton *)sender;

@end
