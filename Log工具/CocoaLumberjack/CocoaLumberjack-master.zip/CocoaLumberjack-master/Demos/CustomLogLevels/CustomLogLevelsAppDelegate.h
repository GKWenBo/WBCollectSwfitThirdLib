//
//  CustomLogLevelsAppDelegate.h
//  CustomLogLevels
//
//  CocoaLumberjack Demos
//

#import <Cocoa/Cocoa.h>

@interface CustomLogLevelsAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *__unsafe_unretained window;
}

@property (unsafe_unretained) IBOutlet NSWindow *window;

@end
