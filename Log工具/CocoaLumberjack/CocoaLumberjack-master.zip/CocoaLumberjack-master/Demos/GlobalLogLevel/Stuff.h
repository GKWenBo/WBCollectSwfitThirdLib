//
//  Stuff.h
//  GlobalLogLevel
//
//  CocoaLumberjack Demos
//

#import <Cocoa/Cocoa.h>

@interface Stuff : NSObject

+ (void)doStuff;

@end
