//
//  GlobalLogLevelAppDelegate.h
//  GlobalLogLevel
//
//  CocoaLumberjack Demos
//

#import <Cocoa/Cocoa.h>

@interface GlobalLogLevelAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *__unsafe_unretained window;
}

@property (unsafe_unretained) IBOutlet NSWindow *window;

@end
