//
//  MyLogging.h
//  GlobalLogLevel
//
//  CocoaLumberjack Demos
//

#import <CocoaLumberjack/CocoaLumberjack.h>

extern DDLogLevel ddLogLevel;
