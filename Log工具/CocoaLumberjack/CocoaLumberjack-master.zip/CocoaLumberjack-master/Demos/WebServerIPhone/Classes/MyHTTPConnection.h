//
//  MyHTTPConnection.h
//  WebServerIPhone
//
//  CocoaLumberjack Demos
//

#import <Foundation/Foundation.h>
#import "HTTPConnection.h"

@interface MyHTTPConnection : HTTPConnection

@end
