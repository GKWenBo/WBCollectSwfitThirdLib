//
//  WebServerIPhoneViewController.h
//  WebServerIPhone
//
//  CocoaLumberjack Demos
//

#import <UIKit/UIKit.h>

@interface WebServerIPhoneViewController : UIViewController

@end
