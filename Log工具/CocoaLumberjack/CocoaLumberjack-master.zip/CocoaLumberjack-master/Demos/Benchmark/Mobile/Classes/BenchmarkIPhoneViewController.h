//
//  BenchmarkIPhoneViewController.h
//  BenchmarkIPhone
//
//  CocoaLumberjack Demos
//

#import <UIKit/UIKit.h>

@interface BenchmarkIPhoneViewController : UIViewController

@end
