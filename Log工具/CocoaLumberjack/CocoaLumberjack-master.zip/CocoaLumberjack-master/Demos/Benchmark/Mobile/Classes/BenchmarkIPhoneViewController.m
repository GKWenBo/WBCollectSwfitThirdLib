//
//  BenchmarkIPhoneViewController.m
//  BenchmarkIPhone
//
//  CocoaLumberjack Demos
//

#import "BenchmarkIPhoneViewController.h"

@implementation BenchmarkIPhoneViewController

@end
