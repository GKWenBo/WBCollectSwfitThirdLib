This Xcode project provides a sample custom formatter.  It shows how one can customize the output format of a log message.  This particular example demonstrates prefixing the file name, function, and line number before a log message.

For more information on custom formatters, see the Wiki article:
https://github.com/CocoaLumberjack/CocoaLumberjack/wiki/CustomFormatters
