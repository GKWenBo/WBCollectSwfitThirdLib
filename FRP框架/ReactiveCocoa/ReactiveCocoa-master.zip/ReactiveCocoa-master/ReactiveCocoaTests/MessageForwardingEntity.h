#import <Foundation/Foundation.h>

@interface MessageForwardingEntity : NSObject
@property(nonatomic) BOOL hasInvoked;
@end
