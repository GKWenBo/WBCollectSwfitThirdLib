import Foundation
import ReactiveSwift

extension NSObject: ReactiveExtensionsProvider {}
