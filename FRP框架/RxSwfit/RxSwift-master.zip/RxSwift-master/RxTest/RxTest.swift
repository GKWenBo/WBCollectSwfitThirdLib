//
//  RxTest.swift
//  RxTest
//
//  Created by Krunoslav Zaher on 12/19/15.
//  Copyright © 2015 Krunoslav Zaher. All rights reserved.
//

/// Virtual time type.
public typealias TestTime = Int

