## Playgrounds

To use playgrounds:

* Open `Rx.xcworkspace`
* Build the `RxSwift` scheme on `My Mac`.
* Open `Rx` playground in the `Rx.xcworkspace` tree view.
* Choose `View > Debug Area > Show Debug Area`
