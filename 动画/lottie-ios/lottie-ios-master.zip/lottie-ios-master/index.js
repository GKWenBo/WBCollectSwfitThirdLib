throw new Error('NPM Module \'lottie-ios\' has no main JavaScript export.');
