//
// Created by Erik Little on 10/21/17.
//

#import "SocketIO_Tests-Swift.h"

@import XCTest;
@import SocketIO;

@interface ManagerObjectiveCTest : XCTestCase

@property TestSocket* socket;
@property TestSocket* socket2;
@property TestManager* manager;

@end
