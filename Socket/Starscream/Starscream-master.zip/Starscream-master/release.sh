#!/bin/bash

bundle install
bundle exec fastlane release
