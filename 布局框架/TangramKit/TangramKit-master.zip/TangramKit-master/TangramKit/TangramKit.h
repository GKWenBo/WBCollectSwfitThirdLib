//
//  TangramKit.h
//  TangramKit
//
//  Created by 韩威 on 2016/12/22.
//  Copyright © 2016年 youngsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TangramKit.
FOUNDATION_EXPORT double TangramKitVersionNumber;

//! Project version string for TangramKit.
FOUNDATION_EXPORT const unsigned char TangramKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TangramKit/PublicHeader.h>


