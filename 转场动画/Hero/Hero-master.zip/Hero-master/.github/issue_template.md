<!--
ℹ We use Github issues for bug reports, feature requests, general support, and questions about the library.

Please fill out this template when filing an issue.
-->

## What did you do?

<!-- Please replace this with what you did. -->

## What did you expect to happen?

<!-- Please replace this with what you expected to happen. -->

##  What happened instead?

<!-- Please replace this with of what happened instead. -->

## General Information

* Hero Version:

* iOS Version(s):

* Swift Version:

* Devices/Simulators:

* Reproducible in Examples? (Yes/No):

## Demo Project

<!-- Please link to or upload a project we can download that reproduces the issue. -->




