1.0.0

* init project
* support capture UIScrollView & UIWebView & WKWebView content

1.0.1

* fixed device scale problem

1.0.2

* WKWebView Screenshots perfect support
* WKWebView support two difference method to capture (scroll & not scroll)

1.0.3

* optimize WKWebView Screenshots, fixed NavigationBar offset problem

1.0.4

* Fix Crash Bug with nil return

1.0.5

* Compatible to Swift 3.0 which contributed by [Lafree317](https://github.com/Lafree317).

1.0.6

* fixed the problem that isCapurting always return false