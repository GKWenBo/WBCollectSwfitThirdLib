//
//  SwViewCapture.h
//  SwViewCapture
//
//  Created by chenxing.cx on 15/10/29.
//  Copyright © 2015年 Startry. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwViewCapture.
FOUNDATION_EXPORT double SwViewCaptureVersionNumber;

//! Project version string for SwViewCapture.
FOUNDATION_EXPORT const unsigned char SwViewCaptureVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwViewCapture/PublicHeader.h>


